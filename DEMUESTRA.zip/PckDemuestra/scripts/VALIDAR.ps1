param(
  [string] $Proyecto = "",
  [switch] $IncluirYaEvaluado
)

$ErrorActionPreference = "Stop"
$RepoRoot = Resolve-Path (Join-Path $PSScriptRoot "..\..")
Set-Location $RepoRoot

Write-Host "Descargando/actualizando cache de Mathlib..."
lake exe cache get

function Invoke-ProyectoLean {
  param([string] $ProyectoPath)

  $leanFiles = Get-ChildItem -Path $ProyectoPath -Filter "*.lean" -File -Recurse -ErrorAction SilentlyContinue

  foreach ($leanFile in $leanFiles) {
    Write-Host "Compilando $($leanFile.FullName)"
    lake env lean $leanFile.FullName
  }
}

if ($Proyecto -ne "") {
  $proyectoPath = Join-Path "Proyectos" $Proyecto
  if (-not (Test-Path $proyectoPath)) {
    $proyectoPath = Join-Path "YaEvaluado" $Proyecto
  }
  if (-not (Test-Path $proyectoPath)) {
    throw "No existe el proyecto '$Proyecto' en Proyectos ni en YaEvaluado."
  }
  Invoke-ProyectoLean $proyectoPath
} else {
  Get-ChildItem -Path "Proyectos" -Directory | ForEach-Object {
    Invoke-ProyectoLean $_.FullName
  }

  if ($IncluirYaEvaluado) {
    Get-ChildItem -Path "YaEvaluado" -Directory | ForEach-Object {
      Invoke-ProyectoLean $_.FullName
    }
  }
}

Write-Host "Compilando agregador Lean..."
lake build

Write-Host "Validacion terminada."
