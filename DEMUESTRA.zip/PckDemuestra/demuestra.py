# PckDemuestra/demuestra.py
# DEMUESTRA — controlador de validación Lean 4
#
# Versión corregida:
# - No llama a lake si no hay archivos .lean.
# - No ejecuta "lake build" para validar archivos individuales.
# - Compila cada .lean con "lake env lean <archivo>".
# - La caché de Mathlib es opcional y se ejecuta solo si se solicita.
# - Todos los subprocess tienen timeout.
# - Compatible con app.validar(nombre=PROYECTO, preparar_cache=...).

from __future__ import annotations

from pathlib import Path
import logging
import os
import shutil
import subprocess
from typing import Optional, Dict, List, Any


DEFAULT_TIMEOUT = 180
CACHE_TIMEOUT = 900


def _buscar_raiz_demuestra(desde: Path) -> Path:
    """
    Busca hacia arriba una carpeta que contenga PckDemuestra y Proyectos.
    Si no la encuentra, usa la carpeta indicada.
    """
    p = desde.resolve()
    if p.is_file():
        p = p.parent

    for candidato in [p, *p.parents]:
        if (candidato / "PckDemuestra").is_dir() and (candidato / "Proyectos").is_dir():
            return candidato

    return p


def _crear_logger(raiz_demuestra: Path) -> logging.Logger:
    logger = logging.getLogger("Demuestra")

    if getattr(logger, "_demuestra_configurado", False):
        return logger

    logger.setLevel(logging.INFO)
    logger.propagate = False

    logs = raiz_demuestra / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    log_file = logs / "demuestra.log"

    formato = logging.Formatter(
        "%(asctime)s - Demuestra - %(levelname)s - %(message)s"
    )

    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(formato)
    logger.addHandler(fh)

    ch = logging.StreamHandler()
    ch.setFormatter(formato)
    logger.addHandler(ch)

    logger._demuestra_configurado = True

    logger.info("=" * 50)
    logger.info("Sistema DEMUESTRA inicializado.")
    logger.info("Log guardado en: %s", log_file.resolve())

    return logger


def _ejecutar(
    comando: List[str],
    cwd: Path,
    timeout: int = DEFAULT_TIMEOUT,
) -> subprocess.CompletedProcess:
    """
    Ejecuta un comando sin shell y captura stdout/stderr.

    Devuelve CompletedProcess incluso cuando el ejecutable no existe o
    se alcanza el timeout, usando códigos sintéticos:
      127 -> ejecutable no encontrado
      124 -> timeout
    """
    try:
        return subprocess.run(
            comando,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            shell=False,
        )
    except FileNotFoundError as exc:
        return subprocess.CompletedProcess(
            comando,
            127,
            stdout="",
            stderr=f"No se encontró el ejecutable: {comando[0]}\n{exc}",
        )
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout or ""
        stderr = exc.stderr or ""
        if isinstance(stdout, bytes):
            stdout = stdout.decode("utf-8", errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode("utf-8", errors="replace")

        return subprocess.CompletedProcess(
            comando,
            124,
            stdout=stdout,
            stderr=(
                stderr
                + f"\nTIMEOUT: el comando superó {timeout} segundos: "
                + " ".join(comando)
            ),
        )


class Demuestra:
    """
    Controlador de proyectos Lean.

    Formas de uso aceptadas:

        app = Demuestra()
        app = Demuestra(__file__)
        app = Demuestra(Path(...))

        info = app.inspeccionar(nombre="ES_46_RV5")
        code = app.validar(
            nombre="ES_46_RV5",
            preparar_cache=False
        )
    """

    def __init__(self, raiz: Optional[object] = None):
        origen = Path(raiz).resolve() if raiz is not None else Path.cwd().resolve()

        # Si se pasa un fichero (por ejemplo __file__), usar su carpeta.
        if origen.is_file():
            origen = origen.parent

        self.origen = origen
        self.raiz_demuestra = _buscar_raiz_demuestra(origen)
        self.raiz = origen
        self.logger = _crear_logger(self.raiz_demuestra)

    # ------------------------------------------------------------------
    # Resolución del proyecto
    # ------------------------------------------------------------------

    def _resolver_proyecto(self, nombre: Optional[str] = None) -> Path:
        """
        Resuelve la raíz del proyecto de forma flexible.

        Casos:
        1. El objeto se crea dentro de Proyectos/ES_46_RV5:
           usa esa carpeta.
        2. Se crea desde la raíz DEMUESTRA y se pasa nombre:
           usa DEMUESTRA/Proyectos/<nombre>.
        3. Se pasa directamente la raíz del proyecto:
           usa esa raíz.
        """
        actual = self.origen.resolve()

        if nombre:
            # Si ya estamos dentro del proyecto pedido.
            if actual.name == nombre:
                return actual

            # Si actual tiene subcarpeta Proyectos/nombre.
            candidato = actual / "Proyectos" / nombre
            if candidato.is_dir():
                return candidato.resolve()

            # Desde la raíz detectada de DEMUESTRA.
            candidato = self.raiz_demuestra / "Proyectos" / nombre
            if candidato.is_dir():
                return candidato.resolve()

        # Detectar que estamos ya en una carpeta de proyecto.
        if (actual / "lean").is_dir():
            return actual

        # Último recurso: con nombre, devolver la ruta esperada aunque
        # aún no exista, para producir un mensaje claro después.
        if nombre:
            return (self.raiz_demuestra / "Proyectos" / nombre).resolve()

        return actual

    # ------------------------------------------------------------------
    # Archivos Lean
    # ------------------------------------------------------------------

    @staticmethod
    def _archivos_lean(proyecto: Path) -> List[Path]:
        """
        Busca archivos Lean del proyecto.
        Prioriza proyecto/lean, pero acepta .lean en subdirectorios.
        Ignora .lake para no compilar dependencias/cache.
        """
        lean_dir = proyecto / "lean"

        if lean_dir.is_dir():
            archivos = sorted(p.resolve() for p in lean_dir.rglob("*.lean"))
        else:
            archivos = sorted(
                p.resolve()
                for p in proyecto.rglob("*.lean")
                if ".lake" not in p.parts
            )

        return archivos

    # ------------------------------------------------------------------
    # Inspección
    # ------------------------------------------------------------------

    def inspeccionar(self, nombre: Optional[str] = None) -> Dict[str, Any]:
        proyecto = self._resolver_proyecto(nombre)
        self.raiz = proyecto

        archivos = self._archivos_lean(proyecto) if proyecto.exists() else []

        info = {
            "nombre": nombre or proyecto.name,
            "raiz": proyecto,
            "archivos_lean": archivos,
            "cantidad": len(archivos),
        }

        # Mantener salida compatible con tus pruebas.
        print(f"Proyecto: {info['nombre']}")
        print(f"Raiz: {proyecto}")
        print(f"Archivos Lean: {len(archivos)}")
        for archivo in archivos:
            print(f"  - {archivo}")

        return info

    # ------------------------------------------------------------------
    # Entorno
    # ------------------------------------------------------------------

    def comprobar_lake(self, proyecto: Path) -> bool:
        """
        Comprueba que 'lake' es localizable.
        Usa where.exe/which solo como ayuda informativa; la comprobación
        definitiva se hace ejecutando 'lake --version'.
        """
        resultado = _ejecutar(["lake", "--version"], proyecto, timeout=30)

        if resultado.returncode != 0:
            self.logger.error(
                "No se puede ejecutar lake.\n%s",
                (resultado.stderr or resultado.stdout).strip(),
            )
            return False

        version = (resultado.stdout or resultado.stderr).strip()
        if version:
            self.logger.info("Lake disponible: %s", version.splitlines()[0])

        return True

    def preparar_cache_mathlib(self, proyecto: Path) -> int:
        """
        Descarga/prepara la caché de Mathlib SOLO cuando se solicita.
        Nunca se ejecuta automáticamente en cada validación.
        """
        self.logger.info("Preparando cache de Mathlib...")

        resultado = _ejecutar(
            ["lake", "exe", "cache", "get"],
            proyecto,
            timeout=CACHE_TIMEOUT,
        )

        if resultado.stdout.strip():
            print(resultado.stdout.rstrip())

        if resultado.stderr.strip():
            print(resultado.stderr.rstrip())

        if resultado.returncode != 0:
            self.logger.error(
                "No se pudo preparar cache Mathlib. Código %s.",
                resultado.returncode,
            )
        else:
            self.logger.info("Cache Mathlib preparada correctamente.")

        return resultado.returncode

    # ------------------------------------------------------------------
    # Compilación individual
    # ------------------------------------------------------------------

    def _compilar_archivo(self, proyecto: Path, archivo: Path) -> int:
        """
        Compila exactamente un .lean.

        Se usa:
            lake env lean <ruta>

        No se usa lake build, porque para una auditoría de archivos
        individuales puede compilar objetivos no relacionados y, en un
        proyecto vacío o mal configurado, generar esperas innecesarias.
        """
        try:
            relativo = archivo.relative_to(proyecto)
        except ValueError:
            relativo = archivo

        self.logger.info("Compilando %s", archivo)

        resultado = _ejecutar(
            ["lake", "env", "lean", str(relativo)],
            proyecto,
            timeout=DEFAULT_TIMEOUT,
        )

        salida = (resultado.stdout or "").strip()
        error = (resultado.stderr or "").strip()

        if resultado.returncode == 0:
            if salida:
                print(salida)
            if error:
                # Lean puede emitir warnings por stderr.
                print(error)

            print(f"\nOK: {archivo.name} compilado correctamente.")
            return 0

        print(f"\nNo se pudo compilar {archivo.name}.")
        if salida:
            print(salida)
        if error:
            print(error)

        return resultado.returncode

    # ------------------------------------------------------------------
    # Validación principal
    # ------------------------------------------------------------------

    def validar(
        self,
        nombre: Optional[str] = None,
        preparar_cache: bool = False,
    ) -> int:
        """
        Valida todos los .lean del proyecto.

        Reglas:
        - 0 archivos -> termina inmediatamente; NO llama a lake.
        - preparar_cache=False -> NO ejecuta cache get.
        - cada archivo se compila con lake env lean.
        - devuelve 0 si todos compilan; primer código !=0 si falla alguno.
        """
        proyecto = self._resolver_proyecto(nombre)
        self.raiz = proyecto

        if not proyecto.exists():
            self.logger.error("No existe el proyecto: %s", proyecto)
            print(f"No existe el proyecto: {proyecto}")
            return 2

        archivos = self._archivos_lean(proyecto)

        # CRÍTICO: salir ANTES de cualquier llamada a lake.
        if not archivos:
            mensaje = (
                f"No hay archivos .lean en {proyecto}. "
                "No se ejecuta cache ni compilación."
            )
            self.logger.warning(mensaje)
            print(mensaje)
            return 0

        # Solo ahora tiene sentido comprobar Lean/Lake.
        if not self.comprobar_lake(proyecto):
            return 127

        # Caché solo bajo petición explícita.
        if preparar_cache:
            rc_cache = self.preparar_cache_mathlib(proyecto)
            if rc_cache != 0:
                return rc_cache

        fallos = []

        for archivo in archivos:
            rc = self._compilar_archivo(proyecto, archivo)
            if rc != 0:
                fallos.append((archivo, rc))

        if fallos:
            self.logger.error(
                "Validación Lean terminada con %d archivo(s) fallido(s).",
                len(fallos),
            )
            print("\nValidacion Lean terminada con errores:")
            for archivo, rc in fallos:
                print(f"  - {archivo.name}: codigo {rc}")
            return fallos[0][1] or 1

        self.logger.info(
            "Validación Lean correcta: %d archivo(s).",
            len(archivos),
        )
        print(
            f"\nValidacion Lean correcta: "
            f"{len(archivos)} archivo(s) compilado(s)."
        )
        return 0


__all__ = ["Demuestra"]
